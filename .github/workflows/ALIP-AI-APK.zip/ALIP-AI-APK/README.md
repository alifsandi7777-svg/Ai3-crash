# ALIP AI - Tutorial Buat APK di GitHub

## 1. Amankan API Key dulu
API key yang kamu kirim di chat sudah terlihat orang lain. Segera:
1. Buka https://console.groq.com/keys
2. Hapus (revoke) key lama, lalu buat key baru.
Jangan pernah menaruh key langsung di kode, karena repo publik bisa dilihat siapa saja.

## 2. Buat repo GitHub
1. Buka github.com → New repository → beri nama `ALIP-AI-APK`.
2. Ekstrak `ALIP-AI-APK.zip`, lalu upload semua isinya (termasuk folder `.github`).
   Cara paling mudah: tombol "uploading an existing file" lalu drag & drop.

## 3. Pasang API key sebagai Secret
1. Di repo: Settings → Secrets and variables → Actions → New repository secret.
2. Name: `GROQ_API_KEY`
3. Secret: isi dengan key baru dari Groq, lalu Save.

## 4. Build APK
1. Buka tab Actions → pilih "Build APK" → Run workflow.
2. Tunggu sekitar 5–10 menit sampai tanda centang hijau muncul.
3. Klik workflow yang selesai → bagian Artifacts → download `ALIP-AI-APK`.
4. Di dalam zip ada `app-debug.apk`.

## 5. Pasang di HP
1. Pindahkan `app-debug.apk` ke HP, buka, lalu izinkan "Instal dari sumber tidak dikenal".
2. Buka ALIP AI, masukkan password: `ALIPAI2026`.
3. Tekan Jalankan, lalu izinkan "Tampil di atas aplikasi lain", kembali, dan tekan Jalankan lagi.
   Bubble ALIP AI akan muncul di layar; tap untuk membuka kotak tanya.

## Catatan
- Logo masih berupa teks "ALIP". Untuk logo gambar, ganti TextView di MainActivity dengan ImageView.
- Ukuran font, warna, dan opacity bisa diatur di menu Setting.
- Footer "@ALIP_🙌" ada di setiap layar.
