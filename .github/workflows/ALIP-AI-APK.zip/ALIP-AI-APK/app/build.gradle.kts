plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alip.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.alip.ai"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
        val key = System.getenv("GROQ_API_KEY")?.takeIf { it.isNotBlank() } ?: "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"
        buildConfigField("String", "GROQ_API_KEY", "\"$key\"")
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
