package com.alip.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GroqClient {
    private const val URL_CHAT = "https://api.groq.com/openai/v1/chat/completions"
    const val MODEL_TEXT = "llama-3.3-70b-versatile"
    const val MODEL_VISION = "meta-llama/llama-4-scout-17b-16e-instruct"

    // Panggil di background thread saja
    fun ask(messages: JSONArray, model: String = MODEL_TEXT): String {
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.7)

        val conn = (URL(URL_CHAT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${BuildConfig.GROQ_API_KEY}")
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) return "Error $code: ${raw.take(300)}"

        return JSONObject(raw).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    fun system(text: String): JSONObject = JSONObject().put("role", "system").put("content", text)
    fun user(text: String): JSONObject = JSONObject().put("role", "user").put("content", text)
}
