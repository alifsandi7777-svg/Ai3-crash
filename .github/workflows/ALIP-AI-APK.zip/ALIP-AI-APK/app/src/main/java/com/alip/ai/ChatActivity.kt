package com.alip.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class ChatActivity : Activity() {
    private lateinit var mode: String
    private val history = JSONArray()
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    companion object {
        private const val REQ_IMG = 42
        fun start(c: Context, mode: String) {
            c.startActivity(
                Intent(c, ChatActivity::class.java)
                    .putExtra("mode", mode)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val ctx: Context = this
        mode = intent.getStringExtra("mode") ?: "run"

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background()
        }

        val robotH = if (mode == "run") 260 else 120
        col.addView(RobotView(ctx), LinearLayout.LayoutParams(-1, Ui.dp(ctx, robotH)))

        box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 12), 0)
        }
        scroll = ScrollView(ctx).apply { addView(box) }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(ctx).apply {
            hint = "Tanyakan sesuatu..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            background = Ui.glass(ctx, 30f)
            setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 10), Ui.dp(ctx, 16), Ui.dp(ctx, 10))
        }
        val pick = Ui.button(ctx, "📷") { pickImage() }
        val send = Ui.button(ctx, "➤") { sendText() }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 4))
            addView(pick)
            addView(input, LinearLayout.LayoutParams(0, -2, 1f))
            addView(send)
        }
        col.addView(row)
        col.addView(Ui.footerText(ctx), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = Ui.dp(ctx, 6) })
        setContentView(col)
        greet()
    }

    private fun greet() {
        when (mode) {
            "kali" -> addMsg(tables(true), false)
            "bagi" -> addMsg(tables(false), false)
            "iq" -> send("Mulai tes IQ, berikan soal pertama.")
            "scan" -> addMsg("Tekan 📷 untuk memilih foto, lalu tanyakan sesuatu tentang foto itu.", false)
            else -> addMsg("Halo, aku LITEX VIP. Ada yang bisa kubantu belajar hari ini?", false)
        }
    }

    private fun tables(kali: Boolean): String {
        val sb = StringBuilder()
        for (n in 1..10) {
            sb.append(if (kali) "Tabel $n\n" else "Pembagian dengan $n\n")
            for (k in 1..10) {
                if (kali) sb.append("$n x $k = ${n * k}\n")
                else sb.append("${n * k} ÷ $n = $k\n")
            }
            sb.append("\n")
        }
        return sb.toString()
    }

    private fun systemPrompt(): String = when (mode) {
        "coding" -> "Kamu adalah asisten coding. Jawab dalam bahasa Indonesia, berikan kode lengkap dan penjelasan singkat."
        "belajar" -> "Kamu guru coding untuk pemula. Jelaskan step by step dalam bahasa Indonesia dengan contoh kecil."
        "iq" -> "Kamu pembuat tes IQ. Berikan SATU soal pilihan ganda (A-D) per pesan dalam bahasa Indonesia. Jika user menjawab, nilai jawabannya (benar/salah + penjelasan singkat), lalu berikan soal berikutnya. Setelah 5 soal, beri skor estimasi."
        "scan" -> "Kamu menganalisis foto. Jelaskan isi foto dan bantu menjawab soal yang ada di dalamnya, dalam bahasa Indonesia."
        else -> "Kamu adalah LITEX VIP, asisten yang membantu siswa mengatasi kesulitan belajar. Jawab dalam bahasa Indonesia, jelas dan ringkas."
    }

    private fun addMsg(t: String, user: Boolean): TextView {
        val tv = Ui.text(this, t, 15f).apply {
            gravity = Gravity.START
            background = Ui.glass(this@ChatActivity, 28f)
            val p = Ui.dp(this@ChatActivity, 14)
            setPadding(p, Ui.dp(this@ChatActivity, 10), p, Ui.dp(this@ChatActivity, 10))
        }
        val lp = LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (user) Gravity.END else Gravity.START
            setMargins(0, 8, 0, 8)
        }
        box.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun sendText() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        send(t)
    }

    private fun send(text: String, img: String? = null) {
        addMsg(text, true)
        history.put(GroqClient.user(text))
        val thinking = addMsg("⏳ LITEX VIP sedang berpikir...", false)

        val msgs = JSONArray().put(GroqClient.system(systemPrompt()))
        for (i in 0 until history.length()) msgs.put(history.get(i))
        if (img != null) {
            val last = msgs.length() - 1
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", text))
                .put(JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$img")))
            msgs.put(last, JSONObject().put("role", "user").put("content", content))
        }
        val model = if (img != null) GroqClient.MODEL_VISION else GroqClient.MODEL_TEXT

        Thread {
            val reply = try { GroqClient.ask(msgs, model) } catch (e: Exception) { "Gagal terhubung: ${e.message}" }
            runOnUiThread {
                thinking.text = reply
                history.put(JSONObject().put("role", "assistant").put("content", reply))
            }
        }.start()
    }

    private fun pickImage() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_IMG)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_IMG || resultCode != RESULT_OK || uri == null) return
        val question = input.text.toString().trim().ifEmpty { "Jelaskan isi foto ini dan bantu jawab jika ada soal." }
        input.setText("")
        Thread {
            try {
                val stream = contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(stream)
                stream?.close()
                val scale = 1024f / maxOf(bmp.width, bmp.height)
                val small = if (scale < 1f)
                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                else bmp
                val out = ByteArrayOutputStream()
                small.compress(Bitmap.CompressFormat.JPEG, 80, out)
                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                runOnUiThread { send(question, b64) }
            } catch (e: Exception) {
                runOnUiThread { addMsg("Gagal membuka foto: ${e.message}", false) }
            }
        }.start()
    }
}
