package com.alip.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private val pass = "ALIPAI2026"

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        root = FrameLayout(this).apply { background = Ui.background() }
        setContentView(root)
        showSplash()
    }

    private fun setScreen(v: View) {
        root.removeAllViews()
        root.addView(Ui.withFooter(this, v), FrameLayout.LayoutParams(-1, -1))
    }

    // Loading 1% - 100% selama 13 detik (100 x 130ms)
    private fun showSplash() {
        val ctx: Context = this
        val col = Ui.column(ctx).apply { gravity = Gravity.CENTER }
        val logo = Ui.text(ctx, "LITEX", 26f).apply {
            typeface = Typeface.DEFAULT_BOLD
            background = Ui.glass(ctx, 200f)
        }
        col.addView(logo, LinearLayout.LayoutParams(Ui.dp(ctx, 130), Ui.dp(ctx, 130)))
        col.addView(Ui.text(ctx, "LITEX VIP - MTS", 32f).apply { typeface = Typeface.DEFAULT_BOLD })
        col.addView(Ui.text(ctx, "@AI Entertainment", 16f, Color.LTGRAY))
        val pct = Ui.text(ctx, "0%", 18f)
        col.addView(pct, LinearLayout.LayoutParams(-2, -2).apply { topMargin = Ui.dp(ctx, 24) })
        setScreen(col)

        var p = 0
        val tick = object : Runnable {
            override fun run() {
                p++
                pct.text = "$p%"
                if (p < 100) h.postDelayed(this, 130) else showLogin()
            }
        }
        h.postDelayed(tick, 130)
    }

    private fun showLogin() {
        val ctx: Context = this
        val col = Ui.column(ctx)
        col.addView(Ui.text(ctx, "LITEX VIP", 30f).apply { typeface = Typeface.DEFAULT_BOLD })
        val pw = EditText(ctx).apply {
            hint = "Masukkan password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            background = Ui.glass(ctx, 30f)
            setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 14), Ui.dp(ctx, 18), Ui.dp(ctx, 14))
        }
        col.addView(pw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 24) })
        val btn = Ui.button(ctx, "Login") {
            if (pw.text.toString() == pass) showWelcome()
            else Toast.makeText(ctx, "Password salah", Toast.LENGTH_SHORT).show()
        }
        col.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 16) })
        setScreen(col)
    }

    private fun showWelcome() {
        val ctx: Context = this
        val t = Ui.text(
            ctx,
            "WELCOME TO LITEX VIP\n\nHelping and providing answers when having difficulties while studying",
            20f
        ).apply { typeface = Typeface.DEFAULT_BOLD }
        t.alpha = 0f
        setScreen(Ui.column(ctx).apply { gravity = Gravity.CENTER; addView(t) })
        t.animate().alpha(1f).setDuration(1500).withEndAction {
            h.postDelayed({ showHome() }, 2000)
        }.start()
    }

    private fun showHome() {
        val ctx: Context = this
        val col = Ui.column(ctx)
        col.addView(Ui.text(ctx, "LITEX VIP", 28f).apply { typeface = Typeface.DEFAULT_BOLD })
        val items: List<Pair<String, () -> Unit>> = listOf(
            "Jalankan" to { runAi() },
            "Tanya Coding (Beta)" to { ChatActivity.start(ctx, "coding") },
            "Belajar Coding (Beta)" to { ChatActivity.start(ctx, "belajar") },
            "Perkalian Lengkap" to { ChatActivity.start(ctx, "kali") },
            "Pembagian Lengkap" to { ChatActivity.start(ctx, "bagi") },
            "TES IQ" to { ChatActivity.start(ctx, "iq") },
            "Scan Foto" to { ChatActivity.start(ctx, "scan") },
            "Setting" to { showSettings() },
            "Stop Layar Mengambang" to { stopService(Intent(ctx, OverlayService::class.java)); Unit }
        )
        for ((label, action) in items) {
            col.addView(
                Ui.button(ctx, label, action),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 12) }
            )
        }
        setScreen(ScrollView(ctx).apply { addView(col) })
    }

    private fun runAi() {
        val ctx: Context = this
        if (!Settings.canDrawOverlays(ctx)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(ctx, "Izinkan 'Tampil di atas aplikasi lain', lalu tekan Jalankan lagi", Toast.LENGTH_LONG).show()
            return
        }
        val svc = Intent(ctx, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        ChatActivity.start(ctx, "run")
    }

    private fun showSettings() {
        val ctx: Context = this
        val col = Ui.column(ctx)
        col.addView(Ui.text(ctx, "Opacity (transparansi)", 16f))
        val seek = SeekBar(ctx).apply { max = 100; progress = Ui.opacity(ctx) }
        col.addView(seek)
        col.addView(Ui.text(ctx, "Warna kaca", 16f))
        val colors = listOf("Biru" to "#4DA3FF", "Ungu" to "#9B59FF", "Hijau" to "#2ECC71", "Putih" to "#FFFFFF")
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, hex) in colors) {
            row.addView(Ui.button(ctx, name) {
                Ui.prefs(ctx).edit().putInt("tint", Color.parseColor(hex)).apply()
            })
        }
        col.addView(row)
        AlertDialog.Builder(ctx)
            .setTitle("Setting")
            .setView(col)
            .setPositiveButton("Simpan") { _, _ ->
                Ui.prefs(ctx).edit().putInt("opacity", seek.progress).apply()
                Toast.makeText(ctx, "Tersimpan", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
