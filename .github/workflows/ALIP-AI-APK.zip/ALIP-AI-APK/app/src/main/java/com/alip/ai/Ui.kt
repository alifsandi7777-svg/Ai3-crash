package com.alip.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import kotlin.math.*

object Ui {
    fun prefs(c: Context) = c.getSharedPreferences("alip_prefs", Context.MODE_PRIVATE)
    fun opacity(c: Context) = prefs(c).getInt("opacity", 45)
    fun tint(c: Context) = prefs(c).getInt("tint", Color.parseColor("#4DA3FF"))
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    // Efek kaca (glass) dengan transparansi & warna dari Setting
    fun glass(c: Context, radius: Float = 36f): GradientDrawable {
        val a = opacity(c) * 255 / 100
        val t = tint(c)
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            colors = intArrayOf(
                Color.argb(min(255, a + 60), 255, 255, 255),
                Color.argb(a, Color.red(t), Color.green(t), Color.blue(t))
            )
            setStroke(2, Color.argb(120, 255, 255, 255))
        }
    }

    fun background() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#05060F"), Color.parseColor("#14163A"), Color.parseColor("#050912"))
    )

    fun text(c: Context, s: String, size: Float = 16f, color: Int = Color.WHITE) =
        TextView(c).apply { text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER }

    fun footerText(c: Context) = text(c, "@ALIP_🙌", 12f, Color.LTGRAY)

    fun column(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(c, 32), dp(c, 40), dp(c, 32), dp(c, 60))
    }

    fun button(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = glass(c, 40f)
        setOnClickListener { onClick() }
    }

    fun withFooter(c: Context, v: View): FrameLayout = FrameLayout(c).apply {
        addView(v, FrameLayout.LayoutParams(-1, -1))
        addView(
            footerText(c),
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(c, 8) }
        )
    }
}

// Robot 3D sederhana dengan label Claude & Gemini yang berputar
class RobotView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var angle = 0f

    init {
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 7000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = min(width, height) / 3.2f
        val bob = sin(angle * PI / 90).toFloat() * s * 0.06f

        p.shader = LinearGradient(
            cx - s, cy - s, cx + s, cy + s,
            intArrayOf(Color.parseColor("#B3E5FF"), Color.parseColor("#3A6BFF"), Color.parseColor("#1B1F3B")),
            null, Shader.TileMode.CLAMP
        )
        cv.drawRoundRect(cx - s * 0.8f, cy - s * 0.7f + bob, cx + s * 0.8f, cy + s * 0.8f + bob, s * 0.3f, s * 0.3f, p)
        p.shader = null

        p.color = Color.parseColor("#00E5FF")
        cv.drawCircle(cx - s * 0.3f, cy - s * 0.15f + bob, s * 0.14f, p)
        cv.drawCircle(cx + s * 0.3f, cy - s * 0.15f + bob, s * 0.14f, p)

        p.color = Color.WHITE
        cv.drawLine(cx, cy - s * 0.7f + bob, cx, cy - s * 1.0f + bob, p)
        cv.drawCircle(cx, cy - s * 1.05f + bob, s * 0.09f, p)

        p.textSize = s * 0.2f
        p.textAlign = Paint.Align.CENTER
        listOf("Claude" to "#FF9F5A", "Gemini" to "#4FC3F7").forEachIndexed { i, pair ->
            val a = Math.toRadians((angle + i * 180).toDouble())
            val x = cx + (cos(a) * s * 1.25).toFloat()
            val y = cy + (sin(a) * s * 0.55).toFloat()
            p.color = Color.parseColor(pair.second)
            cv.drawRoundRect(x - s * 0.5f, y - s * 0.18f, x + s * 0.5f, y + s * 0.18f, s * 0.18f, s * 0.18f, p)
            p.color = Color.WHITE
            cv.drawText(pair.first, x, y + p.textSize * 0.35f, p)
        }
    }
}
