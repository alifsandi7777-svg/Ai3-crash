package com.alip.ai

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONArray

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotif())
        addBubble()
    }

    private fun buildNotif(): Notification {
        val chId = "alip_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(chId, "ALIP AI - LiteX", NotificationManager.IMPORTANCE_LOW))
            Notification.Builder(this, chId)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("ALIP AI - LiteX aktif")
            .setContentText("Layar mengambang berjalan")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    private fun params(w: Int, h: Int, focusable: Boolean): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return WindowManager.LayoutParams(w, h, type, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }
    }

    private fun addBubble() {
        val ctx = this
        val b = Ui.text(ctx, "ALIP\nAI", 14f).apply {
            background = Ui.glass(ctx, 200f)
            val pad = Ui.dp(ctx, 12)
            setPadding(pad, pad, pad, pad)
        }
        val lp = params(Ui.dp(ctx, 64), Ui.dp(ctx, 64), false)
        var ix = 0
        var iy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    lp.x = ix + dx.toInt()
                    lp.y = iy + dy.toInt()
                    wm.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel!!)
            panel = null
            return
        }
        val ctx = this
        val out = Ui.text(ctx, "Halo! Tanyakan sesuatu.", 14f).apply { gravity = Gravity.START }
        val input = EditText(ctx).apply {
            hint = "Ketik pertanyaan..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        val send = Ui.button(ctx, "Kirim") {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@button
            out.text = "⏳ Berpikir..."
            Thread {
                val msgs = JSONArray()
                    .put(GroqClient.system("Kamu adalah ALIP AI - LiteX, asisten belajar. Jawab bahasa Indonesia singkat dan jelas."))
                    .put(GroqClient.user(q))
                val r = try { GroqClient.ask(msgs) } catch (e: Exception) { "Gagal: ${e.message}" }
                handler.post { out.text = r }
            }.start()
        }
        val open = Ui.button(ctx, "Buka App") { ChatActivity.start(ctx, "run") }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, -2, 1f))
            addView(send)
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.glass(ctx, 40f)
            val pad = Ui.dp(ctx, 12)
            setPadding(pad, pad, pad, pad)
            addView(out)
            addView(row)
            addView(open)
        }
        val lp = params(Ui.dp(ctx, 300), ViewGroup.LayoutParams.WRAP_CONTENT, true).apply { x = 0; y = 200 }
        wm.addView(box, lp)
        panel = box
    }

    override fun onDestroy() {
        super.onDestroy()
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
    }
}
